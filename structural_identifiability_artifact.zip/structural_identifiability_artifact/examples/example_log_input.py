# Example: run on the demo log
# python run.py --input input/demo_log.csv --window 50 --m-list 4 8 12 --budget 1200 --plot

from domains import toy_saturating
from core.novelty import novelty_rate
from core.stabilization import estimate_t0
from core.critical_time import critical_time
import numpy as np

buckets = toy_saturating.generate()
window = 20
nov = novelty_rate(buckets, window)
t0 = estimate_t0(nov)
g = np.mean(nov[-100:]) - np.mean(nov[:100])
t_star = critical_time(t0, window, abs(g), delta=0.05)

print("Estimated t0:", t0)
print("Estimated gap g:", g)
print("Critical time t*:", t_star)

import numpy as np

def novelty_rate(buckets, window: int):
    """Windowed uniqueness rate: in each window, how many distinct bucket labels appear."""
    n = len(buckets)
    out = np.zeros(n, dtype=float)
    if window <= 0:
        return out
    for t in range(window, n + 1):
        window_slice = buckets[t-window:t]
        out[t-1] = len(set(window_slice)) / window
    return out

def window_delta_novelty(buckets, window: int):
    """Delta novelty over sliding windows: distinct in window (same as novelty_rate)."""
    return novelty_rate(buckets, window)

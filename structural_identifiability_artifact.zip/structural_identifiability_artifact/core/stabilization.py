import numpy as np

def estimate_t0(novelty_series, var_threshold: float = 1e-3, min_tail: int = 50):
    """
    Estimate stabilization time t0 as the earliest index t such that the variance of the tail
    (from t onward) is below var_threshold.
    """
    n = len(novelty_series)
    for t in range(0, max(0, n - min_tail)):
        tail = novelty_series[t:]
        if np.var(tail) <= var_threshold:
            return t
    return n  # no stabilization detected within budget

import hashlib

def bits_to_bucket_prefix(bits: str, m: int) -> int:
    # First m bits as integer
    return int(bits[:m], 2) if m > 0 else 0

def bits_to_bucket_hash(bits: str, m: int) -> int:
    # Stable hash -> take m bits (as integer)
    # Use blake2b for stability across runs/platforms.
    h = hashlib.blake2b(bits.encode("utf-8"), digest_size=8).digest()
    x = int.from_bytes(h, "big")
    if m <= 0:
        return 0
    mask = (1 << m) - 1
    return x & mask

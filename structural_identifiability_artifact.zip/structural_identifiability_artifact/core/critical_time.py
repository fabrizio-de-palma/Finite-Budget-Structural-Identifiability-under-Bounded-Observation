import numpy as np

def critical_time(t0: int, w: int, g: float, delta: float, C: float = 1.0):
    if g <= 0:
        return float("inf")
    return float(t0) + C * (float(w) / (g ** 2)) * float(np.log(1.0 / delta))

def max_identifiable_scale(m_list, t_star_by_m, budget: int):
    feasible = [m for m in m_list if t_star_by_m.get(m, float("inf")) <= budget]
    return max(feasible) if feasible else None

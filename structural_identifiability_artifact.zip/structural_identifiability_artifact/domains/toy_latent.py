import random

def generate(length=1000, latent_phase=300):
    buckets = []
    for t in range(length):
        if t < latent_phase:
            buckets.append(random.randint(0, 20))
        else:
            buckets.append(t + 1000)
    return buckets

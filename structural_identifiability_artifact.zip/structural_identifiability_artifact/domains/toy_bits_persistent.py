import random

def generate_bits(length=2000, k=16):
    """Fresh random k-bit strings."""
    bits = []
    for _ in range(length):
        x = random.getrandbits(k)
        bits.append(format(x, f"0{k}b"))
    return bits

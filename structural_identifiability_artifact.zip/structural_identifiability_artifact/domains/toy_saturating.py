import random

def generate(length=1000, M=50):
    buckets = []
    for t in range(length):
        if t < M:
            buckets.append(t)
        else:
            buckets.append(random.randint(0, M-1))
    return buckets

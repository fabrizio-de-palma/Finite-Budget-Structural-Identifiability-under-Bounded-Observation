import random

def generate_bits(length=2000, k=16, M=200):
    """New buckets until M, then repeat among first M (encoded as k-bit strings)."""
    bits = []
    for t in range(length):
        if t < M:
            x = t % (1 << k)
        else:
            x = random.randint(0, M-1) % (1 << k)
        bits.append(format(x, f"0{k}b"))
    return bits

import random

def generate_bits(length=2000, k=16, latent_phase=600, M=64):
    """Saturating-like for latent_phase, then persistent with fresh bits."""
    bits = []
    for t in range(length):
        if t < latent_phase:
            x = random.randint(0, M-1) % (1 << k)
        else:
            x = random.getrandbits(k)
        bits.append(format(x, f"0{k}b"))
    return bits

import random

def generate(length=1000):
    return [random.randint(0, 10**9) for _ in range(length)]

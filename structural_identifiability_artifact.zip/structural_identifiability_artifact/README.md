# Structural Identifiability Artifact (Version B)

This artifact illustrates **finite-budget structural identifiability** under **bounded observation**.
It estimates, across observational scales `m`, the following structural curves:

- Novelty curve `N_m(t)` (windowed uniqueness rate of observed buckets)
- Stabilization / latency `t0(m)` (when novelty statistics stabilize)
- A simple separability proxy `g_hat(m)` (illustrative; see below)
- Critical identification time `t*(m, delta)`
- Max identifiable scale `m_c(b, delta)` under a finite budget `b`

The artifact is **illustrative**: it visualizes the theory on synthetic domains and can be used on
user-provided logs. It is **not** an empirical validation and does not claim solver performance gains.

## Install
```bash
pip install -r requirements.txt
```

## Run on toy domains
```bash
python run.py --domain toy_latent --window 50 --m-list 4 8 12 --budget 2000 --plot
```

## Run on your own domain (log-driven)
Provide a CSV with either:
- `t,bits` where `bits` is a 0/1 string of length k, OR
- `t,bucket` where `bucket` is any hashable label (int/string).

Example:
```bash
python run.py --input input/demo_log.csv --window 50 --m-list 4 8 12 --budget 2000 --plot
```

### Bucketing
If `bits` are provided, buckets at scale `m` are computed as:
- `prefix`: interpret the first `m` bits as an integer (default)
- `hash`: stable hash of the full bitstring, truncated to `m` bits

Select via `--bucket-mode prefix|hash`.

## Notes on g(m)
The theory defines a separability gap `g(m)=eta(m)-epsilon(m)` between *classes* of regimes.
For a **single** observed run, we provide an *illustrative proxy*:

- `g_hat(m) = |mean(N_m late) - mean(N_m early)|`

This proxy is sufficient to visualize how `t*(m)` reacts to a shrinking/growing gap, but it is
**not** a substitute for class-level estimation when comparing populations of domains.

## Outputs
When `--plot` is enabled, plots are written to `output/`:
- `novelty_curves.png`: N_m(t) across m
- `critical_time.png`: t0(m), t*(m), and m_c(b,delta)

## Adapter template (optional)
See `adapters/adapter_example.py` for a minimal streaming-to-log template.

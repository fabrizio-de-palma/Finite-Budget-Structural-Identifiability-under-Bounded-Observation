"""
Adapter example: how to use the artifact with your own solver/domain.

Goal:
- You have a process/solver that can produce an observation at each step t.
- You decide an observation representation O_k that outputs a bitstring of length k (or a bucket label).
- You log it to CSV, then run run.py in log-driven mode.

This file provides:
- A minimal interface you can implement
- A reference logger that writes `t,bits` or `t,bucket`
"""

import csv
from dataclasses import dataclass
from typing import Optional, Protocol, Union


class BitObserver(Protocol):
    """Return a 0/1 bitstring of fixed length k at each step."""
    k: int
    def observe_bits(self, t: int) -> str: ...


class BucketObserver(Protocol):
    """Return a hashable bucket label at each step."""
    def observe_bucket(self, t: int) -> Union[int, str]: ...


@dataclass
class CSVLogger:
    path: str
    mode: str = "bits"  # "bits" or "bucket"

    def __post_init__(self):
        if self.mode not in ("bits", "bucket"):
            raise ValueError("mode must be 'bits' or 'bucket'")

    def write_bits(self, observer: BitObserver, steps: int):
        with open(self.path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["t", "bits"])
            for t in range(steps):
                bits = observer.observe_bits(t)
                # basic sanity checks
                if not set(bits).issubset({"0", "1"}):
                    raise ValueError(f"Non-binary bits at t={t}: {bits[:64]}...")
                if len(bits) != observer.k:
                    raise ValueError(f"Expected k={observer.k} bits, got {len(bits)} at t={t}")
                w.writerow([t, bits])

    def write_bucket(self, observer: BucketObserver, steps: int):
        with open(self.path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["t", "bucket"])
            for t in range(steps):
                b = observer.observe_bucket(t)
                w.writerow([t, b])


# -----------------------------
# Example stub (replace with your solver)
# -----------------------------

class DummySATObserver:
    """Example: pretend we observe a solver state and compress it into k bits."""
    def __init__(self, k: int = 64):
        self.k = k

    def observe_bits(self, t: int) -> str:
        # Replace this with: extract features from your state, then binarize/quantize into k bits.
        # Here: a deterministic toy pattern.
        x = (t * 2654435761) & ((1 << self.k) - 1)  # multiplicative hash
        return format(x, f"0{self.k}b")


if __name__ == "__main__":
    steps = 2000
    obs = DummySATObserver(k=64)
    logger = CSVLogger(path="input/my_domain_log.csv", mode="bits")
    logger.write_bits(obs, steps=steps)

    print("Wrote input/my_domain_log.csv")
    print("Now run:")
    print("  python run.py --input input/my_domain_log.csv --window 50 --m-list 8 12 16 --budget 2000 --plot")

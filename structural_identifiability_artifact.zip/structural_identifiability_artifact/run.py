import argparse
import csv
import os
from typing import List, Dict, Tuple, Optional

import numpy as np
import matplotlib.pyplot as plt

from core.buckets import bits_to_bucket_prefix, bits_to_bucket_hash
from core.novelty import novelty_rate
from core.stabilization import estimate_t0
from core.critical_time import critical_time, max_identifiable_scale


def parse_args():
    p = argparse.ArgumentParser(description="Structural identifiability probe (toy + log-driven).")
    p.add_argument("--domain", type=str, default=None,
                   help="Toy domain module in domains/, e.g. toy_bits_latent. Mutually exclusive with --input.")
    p.add_argument("--input", type=str, default=None,
                   help="CSV log with columns (t,bits) or (t,bucket).")
    p.add_argument("--bucket-mode", choices=["prefix", "hash"], default="prefix",
                   help="How to derive buckets at scale m from bits.")
    p.add_argument("--window", type=int, default=50, help="Window size w.")
    p.add_argument("--m-list", type=int, nargs="+", default=[4, 8, 12],
                   help="List of scales m to evaluate.")
    p.add_argument("--delta", type=float, default=0.05, help="Confidence parameter delta.")
    p.add_argument("--budget", type=int, default=None, help="Finite budget b (defaults to run length).")
    p.add_argument("--var-threshold", type=float, default=1e-3, help="Variance threshold for t0 estimation.")
    p.add_argument("--min-tail", type=int, default=50, help="Minimum tail length for t0 estimation.")
    p.add_argument("--plot", action="store_true", help="Write plots to output/.")
    p.add_argument("--outdir", type=str, default="output", help="Output directory for plots.")
    return p.parse_args()


def load_from_domain(domain_name: str):
    import importlib
    mod = importlib.import_module(f"domains.{domain_name}")
    if hasattr(mod, "generate_bits"):
        bits = mod.generate_bits()
        return ("bits", bits)
    elif hasattr(mod, "generate"):
        buckets = mod.generate()
        return ("bucket", buckets)
    raise ValueError("Domain module must expose generate_bits() or generate().")


def load_from_csv(path: str):
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        if "bits" in r.fieldnames:
            bits = []
            for row in r:
                bits.append(row["bits"].strip())
            return ("bits", bits)
        if "bucket" in r.fieldnames:
            buckets = []
            for row in r:
                b = row["bucket"]
                try:
                    buckets.append(int(b))
                except Exception:
                    buckets.append(b)
            return ("bucket", buckets)
    raise ValueError("CSV must have column 'bits' or 'bucket'.")


def bits_to_buckets(bits: List[str], m: int, mode: str):
    if mode == "prefix":
        return [bits_to_bucket_prefix(x, m) for x in bits]
    return [bits_to_bucket_hash(x, m) for x in bits]


def estimate_g_hat(novelty: np.ndarray, early_frac: float = 0.2, late_frac: float = 0.2) -> float:
    n = len(novelty)
    e = max(1, int(n * early_frac))
    l = max(1, int(n * late_frac))
    early = novelty[:e]
    late = novelty[-l:]
    return float(abs(np.mean(late) - np.mean(early)))


def main():
    args = parse_args()
    if (args.domain is None) == (args.input is None):
        raise SystemExit("Provide exactly one of --domain or --input.")

    if args.domain:
        kind, data = load_from_domain(args.domain)
    else:
        kind, data = load_from_csv(args.input)

    n = len(data)
    budget = args.budget if args.budget is not None else n

    # Trim to budget for analysis
    data = data[:budget]
    n = len(data)

    m_list = sorted(set(args.m_list))
    results = {}
    novelty_by_m = {}

    for m in m_list:
        if kind == "bits":
            buckets = bits_to_buckets(data, m, args.bucket_mode)
        else:
            buckets = data  # already bucket labels; m only affects reporting
        nov = novelty_rate(buckets, args.window)
        novelty_by_m[m] = nov

        t0 = estimate_t0(nov, var_threshold=args.var_threshold, min_tail=args.min_tail)
        g_hat = estimate_g_hat(nov)
        t_star = critical_time(t0, args.window, g_hat, args.delta, C=1.0)

        results[m] = {"t0": int(t0), "g_hat": float(g_hat), "t_star": float(t_star)}

    t_star_by_m = {m: results[m]["t_star"] for m in m_list}
    m_c = max_identifiable_scale(m_list, t_star_by_m, budget)

    print("=== Structural identifiability summary ===")
    print(f"length/budget b = {budget}")
    print(f"window w = {args.window}, delta = {args.delta}, bucket-mode = {args.bucket_mode}")
    print(f"m_c(b,delta) = {m_c}")
    for m in m_list:
        r = results[m]
        print(f"m={m:>3}  t0={r['t0']:>5}  g_hat={r['g_hat']:.6f}  t*={r['t_star']:.2f}")

    if args.plot:
        os.makedirs(args.outdir, exist_ok=True)

        # Plot 1: novelty curves
        plt.figure()
        for m in m_list:
            plt.plot(novelty_by_m[m], label=f"m={m}")
        plt.xlabel("t")
        plt.ylabel("N_m(t) (windowed uniqueness rate)")
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(args.outdir, "novelty_curves.png"), dpi=200)
        plt.close()

        # Plot 2: critical times vs m
        plt.figure()
        t0s = [results[m]["t0"] for m in m_list]
        tstars = [results[m]["t_star"] for m in m_list]
        plt.plot(m_list, t0s, marker="o", label="t0(m)")
        plt.plot(m_list, tstars, marker="o", label="t*(m)")
        plt.axhline(budget, linestyle="--", label="budget b")
        if m_c is not None:
            plt.axvline(m_c, linestyle="--", label="m_c")
        plt.xlabel("m")
        plt.ylabel("time")
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(args.outdir, "critical_time.png"), dpi=200)
        plt.close()


if __name__ == "__main__":
    main()
